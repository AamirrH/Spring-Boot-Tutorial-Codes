package com.Spring.RESTful.APIs.CodingShuttleCourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingShuttleCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
