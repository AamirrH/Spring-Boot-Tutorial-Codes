package com.Spring.RESTful.APIs.CodingShuttleCourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingShuttleCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingShuttleCourseApplication.class, args);
	}

}
